Thank you for choosing House Menu System v5.0h 
If you have any installation problems, please ICQ me at 40454203 or email me at vaticus@baseworlds.com.  To install the house menu, please read the instructions on each file.
Each file represents a certain Sphere*.scp
 
HMS - Items            This file represents what goes in Sphereitemb1.scp and Sphereitemb2.scp
Spherehouse.scp     This file was made to make your life easier.  Just add it to your Sphere folder                                in the spot where your scripts are located.

Please read each instruction carefully.
* Note
     PLEASE MAKE SURE THAT YOU BACK UP ALL OF YOUR FILES BEFORE ADDING  
     AY TYPE OF SCRIPT!!!

I will not be responsible for what you do not backup incase of incorrect installation.