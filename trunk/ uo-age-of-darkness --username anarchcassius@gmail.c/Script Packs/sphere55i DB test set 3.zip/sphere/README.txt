StaticSphere

There are currently two executables in the StaticSphere suite.  StaticSphere, which 
allows admins to remove objects from their worldfiles and move them into a static
patch file, and SpherePatch, which actually applies the patch file to the static client
files.

StaticSphere is a GUI application, and has a built-in help file.

SpherePatch is a simple console application.  To use SpherePatch, place it in your client
directory and run it with this command syntax:
freezestatic <patchfile name>
The statics will be inserted into a verdata.new  Before using the patched file, 
BACKUP YOUR EXISTING VERDATA.MUL FILE!!!!!!  To use it, simply copy verdata.new over
verdata.mul (after you've backed up verdata.mul).
If you wish for others to use your patch, simply zip up the SpherePatch executable and
patch file.  You'll probably want to include some very detailed instructions (or write a
batch file) on how to use the archive.

Bug reports and/or comments should be sent to the developers at
devteam@fingolfin.net

Thanks, and enjoy!

====================================================
Revision History:

v 1.04 (20 December 2000)
� Various tweaks and fixes in the worldfile analysis/item testing code.
� Tweaked the script loading code.

v 1.03 (18 December 2000)
� Patch objects can be manually removed from the list after the worldfile has been
  analyzed (use the delete key with the objects selected).
� Map rectangles can also be removed (use the delete key).
� Fixed a small memory leak issue that applies only to the .53+ script format.  Previously,
  webpage script objects weren't getting cleaned up on exit.
� Fixed the 'unused tile' problem in SpherePatch.

v 1.02 (5 November 2000)
� Added a worldmap to the main window.  The purpose of this is so that you can
  choose which parts of the world to include and exclude from the 
  freezing process.
� Added a window which shows you which objects have been selected for freezing.
  Eventually, you'll be able to remove them from the list manually.

v 1.01 (2 November 2000)
� Old and new script formats should now be supported.
� Removed FreezeStatic from the archive, and replaced it with SpherePatch.

v 1.0 (October 2000)
� Entries now get saved in the registry, so you don't need to keep putting in the same
  values over and over.
� Scrollbars added to the exclude and include windows.  These also should now allow for
  unlimited entries.

v 1.0 beta 3 (September 8, 2000)
� Another modification to the patch file format, so older patch files are again incompatible
  with freezestatic.
� Freezestatic modified slightly.  Does not include staidx patch entries, as they aren't
  necessary.

v 1.0 beta 2 (August 25, 2000)
� Slight modification to the patch file format, so older patch files are now incompatible
  with freezestatic.
� Freezestatic has been modified.  Now it creates verdata.new instead of the statics files.

v 1.0 beta (August 23, 2000)
� Beta release

