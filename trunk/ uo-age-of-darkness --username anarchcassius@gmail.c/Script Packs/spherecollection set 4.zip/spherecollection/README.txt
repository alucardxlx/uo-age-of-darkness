Sphere Collection v1.0
put together by DarkOgre2@yahoo.com
I DID NOT MAKE THESE SCRIPTS. I AM NOT TAKING CREDIT FOR THEM, I ONLY COMBINED MANY OF THEM TO BUILD A STABLE WORLD!

account name- master
pw- master

account name- player1
pw- player1

and so on.. it's easy enough to change pw in game.

For all the people who love UO and die trying to find help scripting and building worlds. It's hard to find help sometimes ;) Clients included, 2.03 and 3.0. Both work better.

Hopefully this is plug and play. Can't promise anything though. This shard is made up of hundreds of peoples scripts I've compiled to build a stable server. Full trammel spawn. You can just log on and play. Fel is unspawned though, leaving this to the shard admin if they want it. A few errors here and there, but nothing to affect game play. Sphereweb updates was taken out, so don't worry when you see a few errors on startup. You can add them in if you want. Axis won't pick up all the scripts, plenty of secrets to find. For experienced users, you can add all the cool items, otherwise wait to find them as rare loot :) 

The shard will have to be manually saved, I never had any crashes so I saved once a day. It takes about 5 mins to save on my comp.
The shard ran fine on p633, 128mb ram.

All credits can be found in the script files. Too many to mention. Thanks to each and every one you.


